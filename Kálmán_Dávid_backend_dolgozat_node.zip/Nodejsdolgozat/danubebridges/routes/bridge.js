const { json } = require('express');
var express = require('express');
var router = express.Router();

const Bridge = require('../models/bridge');
const Location = require('../models/location');

router.post('/bridges', function (req, res, next) {
    const _id = req.body._id;
    const bridgeName = req.body.bridgeName;
    const description = req.body.description;
    const isPublicRoad = req.body.isPublicRoad;
    const flowKm = req.body.flowKm;
    const routes = req.body.routes;
    const location = req.body.location;
    const deliveryDatuma = req.body.deliveryDatuma;
    const pictureUrl = req.body.pictureUrl;

    const bridge = new Bridge({ _id, bridgeName, description, isPublicRoad, flowKm, routes, location, deliveryDatuma, pictureUrl });

    bridge
        .save(function (err) {
            if (err) {
                return res.status(400).json({ success: false, message: err.message });
            }
            res.status(201).json({});
        })
});


router.get('/bridges/:field/:direction', function (req, res, next) {
    const field = req.params.field;
    const direction = req.params.direction;
    Bridge
        .find()
        .populate("location", "-_id")
        .sort({ [field]: direction })
        .then(bridges => {
            res.json(bridges)
        })
        .catch(err => console.log(err))
});

router.patch('/bridges/:id', function (req, res, next) {
    const id = req.params.id;

    Bridge
        .findById(id).then(doc => {
            if (doc === null) {
                return res.json({
                    'error' : `A hirdetés ${id} azonosítóval nem létezik!`
                })
            }
            Bridge
        .findByIdAndUpdate(id, req.body)
        .then(res.json({message: `A hirdetés ${id} azonosítóval módosítva lett!`}))
        .catch(err => console.log(err))
        })
});

module.exports = router;