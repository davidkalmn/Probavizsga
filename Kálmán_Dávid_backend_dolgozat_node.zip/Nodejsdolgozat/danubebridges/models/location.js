const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const locationsSchema = new Schema({
    _id: Number,
    locationName: {
        type: String,
        required: true,
        unique: true,
        maxlength: 50,
    }
});

module.exports = mongoose.model('Location', locationsSchema, 'locations')