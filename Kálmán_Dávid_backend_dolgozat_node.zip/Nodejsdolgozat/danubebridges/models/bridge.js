const mongoose = require('mongoose');

const Schema = mongoose.Schema;

function arFtValidator(val){
    return val > 0 && val < 2850;
}

function validDate(date) {
    return date < Date.now();
}

const bridgeSchema = new Schema({
    _id: Number,
    bridgeName: {
        type: String,
        unique: true,
        required: true,
        maxlength: 100
    },
    description: {
        type: String,
        required: true,
        maxlength: 3000
    },
    isPublicRoad: {
        type: Boolean,
        default: true
    },
    flowKm: {
        type: Number,
        unique: true,
        required: true,
        validate: [arFtValidator, "A flowKm mező értéke csak 0-mál nagyobb és 2850-nél kisebb lehet!"]
    },
    routes: {
        type: String,
        maxlength: 500
    },
    location: {
        type: Number,
        required: true,
        ref: 'Location'
    },
    deliveryDatuma: {
        type: Date,
        validate: [validDate, "Az aktuális dátumnál nem adhat meg későbbi dátumot a deliveryDate mezőben!"]
    },
    pictureUrl: {
        type: String,
        maxlength: 300
    }

});

module.exports = mongoose.model('Bridge', bridgeSchema, 'bridges');