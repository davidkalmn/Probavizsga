# Backend dolgozat

cmd: express --no-view "name"
npm i --save-dev nodemon

"scripts": {
    "start": "nodemon ./bin/www"
  },

  npm i --save mongoose